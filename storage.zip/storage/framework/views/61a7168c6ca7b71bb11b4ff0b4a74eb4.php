<!DOCTYPE html>
<html>
<head>
    <title>Verify Your Email Address</title>
</head>
<body>
    <h1>Verify Your Email Address</h1>
    <p>Please click the button below to verify your email address.</p>
    <a href="<?php echo e($verificationUrl); ?>">Verify Email Address</a>
    <p>If you did not create an account, no further action is required.</p>
</body>
</html>
<?php /**PATH D:\PROJECT LARAVEL\PBL\demo-dukcapil-skh\resources\views/auth/verify.blade.php ENDPATH**/ ?>