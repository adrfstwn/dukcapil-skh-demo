<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php /**PATH D:\PROJECT LARAVEL\PBL\demo-dukcapil-skh\resources\views/admin/footer.blade.php ENDPATH**/ ?>