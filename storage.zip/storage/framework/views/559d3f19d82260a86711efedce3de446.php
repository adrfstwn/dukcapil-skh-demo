<?php $__env->startSection('content'); ?>
    
    <Section id="profile" class="my-10 md:my-20">
    <?php $__currentLoopData = $profils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-20 justify-center items-start">
                <div class="flex flex-col gap-3 ">
                    <h2 class="font-monserrat font-bold text-2xl md:text-[32px] text-primary_teks"><span
                            class="text-primary text-2xl font-monserrat font-medium">PROFIL</span> <br>
                            <?php echo e($profil->nama); ?></h2>
                    <p class="font-nunito text-primary_teks text-base">
                    <?php echo $profil->deskripsi_profil; ?>

                    </p>
                </div>
                <div class="flex">
                    <img src="<?php echo e(asset('storage/' . $profil->gambar_profil)); ?>" loading="lazy" alt="Logo Kab.Sukoharjo" class="w-80 ">
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </Section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT LARAVEL\PBL\demo-dukcapil-skh\resources\views/profil.blade.php ENDPATH**/ ?>