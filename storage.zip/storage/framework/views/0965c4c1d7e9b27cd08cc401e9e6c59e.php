<?php $__env->startSection('content'); ?>

<section id="news" class="my-10 md:my-20 -z-10">
    <div class="container">
        <div class="flex flex-col md:flex-row justify-between gap-6">
            <div class="flex flex-col gap-6 md:gap-12 w-full md:w-2/3">
                <div class="flex flex-col gap-4">
                    <h2 class="font-monserrat text-2xl md:text-[32px] text-primary_teks ">
                        <span class="font-bold text-primary">Berita</span> Terbaru
                    </h2>
                </div>
                <div class="flex flex-col gap-4">
                    <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-col gap-2">
                            <div class="flex flex-col md:flex-row items-center gap-2">
                                <?php if($berita->gambar_berita): ?>
                                    <div class="relative flex w-full">
                                        <img src="<?php echo e(asset('storage/' . $berita->gambar_berita)); ?>" alt="<?php echo e($berita->judul); ?>"
                                            loading="lazy" class="w-64 md:max-w-72 h-auto rounded-md mr-4">
                                        <div class="absolute  top-4 right-[88px] md:right-4">
                                            <p
                                                class="text-sm rounded-sm text-background_light bg-primary px-2 py-1 uppercase font-semibold font-monserrat">
                                                Informasi</p>
                                        </div>
                                    </div>
                                    <!-- Adjusted width to w-2/5 and added margin-right -->
                                    <div class="flex flex-col gap-3"> <!-- Wrapped button in a div -->
                                        <div class="flex flex-col gap-1">
                                            <a href="<?php echo e(route('berita.detail', $berita->id)); ?>"
                                                class="font-bold font-nunito text-xl md:text-2xl text-primary_teks ">
                                                <?php echo e($berita->judul); ?>

                                            </a>
                                            <p class="text-sm text-secondary_teks font-nunito"><?php echo e($berita->waktu); ?></p>
                                        </div>
                                        <p class="font-nunito text-base text-secondary_teks line-clamp-5 flex-grow">
                                            <!-- Added flex-grow to push the caption to the left -->
                                            <?php echo \Illuminate\Support\Str::limit($berita->deskripsi_berita, 600, '...'); ?>

                                        </p>
                                        <a href="<?php echo e(route('berita.detail', $berita->id)); ?>"
                                            class="px-2 py-1 font-nunito text-base items-start justify-start text-center text-background_light bg-primary rounded-md mt-2 w-40">
                                            <!-- Adjusted padding and margin-top, and added inline styling to limit width -->
                                            Lihat Selengkapnya
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <hr class="border-b-[1px] border-gray-300 mt-6 md:mt-8 rounded-full">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <aside class="md:block md:border-l-[2px] border-gray-200 md:pl-6">
                <h2 class="font-monserrat text-2xl md:text-[32px] text-primary_teks pt-6 md:pt-0"><span
                        class="font-bold text-primary ">Persyaratan</span> Terbaru</h2>
                        <?php $__currentLoopData = $latestPersyaratan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persyaratanTerbaru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="flex flex-col py-3 gap-4">
                            <div class="flex flex-col gap-2">
                        <a href="<?php echo e(route('persyaratan.detail', $persyaratanTerbaru->id)); ?>"
                            class="font-nunito text-base font-semibold text-primary_teks line-clamp-2"><?php echo e($persyaratanTerbaru->judul); ?></a>
                        <p class="font-nunito text-sm md:text-base text-secondary_teks "><?php echo e($persyaratanTerbaru->created_at->format('Y-m-d')); ?></p>
                        <hr class="border-[1.5px] border-gray-200 rounded-full my-3">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </aside>
        </div>
        <div class="flex flex-row justify-center gap-3 mt-6"> <!-- Centered pagination links -->
            <?php echo e($beritas->links()); ?>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT LARAVEL\PBL\demo-dukcapil-skh\resources\views/berita.blade.php ENDPATH**/ ?>