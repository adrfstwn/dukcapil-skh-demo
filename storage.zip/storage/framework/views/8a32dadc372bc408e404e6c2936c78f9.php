<?php $__env->startSection('content'); ?>
    
    <section id="detail-persyaratan" class="my-10 md:my-20">
        <div class="container">
            <div class="flex flex-col md:flex-row justify-between gap-6">
                <div class="flex flex-col gap-12 w-full md:w-2/3">
                    <div class="flex flex-col gap-6 md:gap-12">
                        <div class="flex flex-col gap-2">
                            <p class="text-sm text-primary uppercase font-semibold font-monserrat">
                                <?php echo e($persyaratans->kategori->nama_kategori); ?>

                            </p>
                            <h2 class="font-bold font-nunito text-xl md:text-3xl text-primary_teks">
                                <?php echo e($persyaratans->judul); ?>

                            </h2>
                            <p class="text-sm text-secondary_teks font-nunito"><?php echo e($persyaratans->waktu); ?></p>
                            <div class="flex flex-col gap-6 max-w-screen-lg">
                                <?php if($persyaratans->file): ?>
                                    <?php
                                        $extension = pathinfo($persyaratans->file, PATHINFO_EXTENSION);
                                    ?>
                                    <?php if(in_array($extension, ['jpg', 'jpeg', 'png'])): ?>
                                        <img src="<?php echo e(asset('storage/' . $persyaratans->file)); ?>" loading="lazy"
                                            alt="<?php echo e($persyaratans->judul); ?>"
                                            class="w-full h-full object-cover object-center rounded-lg">
                                        <div class="mt-4">
                                            <a href="<?php echo e(asset('storage/' . $persyaratans->file)); ?>" download
                                                class="text-base text-neutral-50 bg-primary px-2 py-1 rounded-md"
                                                target="_blank">Download Gambar</a>
                                        </div>
                                    <?php elseif($extension == 'pdf'): ?>
                                        <iframe src="<?php echo e(asset('storage/' . $persyaratans->file)); ?>" width="100%"
                                            height="700px" frameborder="0" class="rounded-xl">Formulir</iframe>
                                        <div class="">
                                            <a href="<?php echo e(asset('storage/' . $persyaratans->file)); ?>" download
                                                class="text-base text-neutral-50 bg-primary px-2 py-1 rounded-md"
                                                target="_blank">Download File PDF</a>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <p class="text-base md:text-lg text-secondary_teks">
                                    <?php echo $persyaratans->deskripsi_persyaratan; ?>

                                </p>
                            </div>
                        </div>
                        <hr class="border-b-[1px] border-gray-300 mt-6 md:mt-8 rounded-full">
                    </div>
                    <div class="flex flex-col gap-4">
                        <h2 class="font-monserrat text-2xl md:text-[32px] text-primary_teks pt-6 md:pt-0 border-b-2 pb-4">
                            <span class="font-bold text-primary">Berita</span> Terbaru
                        </h2>
                        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                        <?php $__currentLoopData = $beritaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-col gap-y-3 p-4 border rounded-md">
                                    <img src="<?php echo e(asset('storage/' . $berita->gambar_berita)); ?>" loading="lazy" alt="<?php echo e($berita->judul); ?>"
                                        class="w-full max-h-[450px] object-cover object-center rounded-lg">
                                    <div class="flex gap-1 md:gap-4 items-center justify-between md:justify-start">
                                        <p class="px-2 py-1 bg-primary rounded-sm text-background_light text-xs">Berita</p>
                                        <p class="text-xs text-secondary_teks font-nunito text-end"><?php echo e($berita->waktu); ?>

                                        </p>
                                    </div>
                                    <a href="<?php echo e(route('berita.detail', $berita->id)); ?>"
                                        class="text-base font-bold font-nunito text-primary_teks line-clamp-2"><?php echo e($berita->judul); ?></a>
                                    <p class="text-sm text-secondary_teks line-clamp-3">
                                        <?php echo Str::limit($berita->deskripsi_berita, 100); ?></p>
                                    <a href="<?php echo e(route('berita.detail', $berita->id)); ?>"
                                        class="mt-2 px-4 py-2 bg-primary text-background_light text-sm rounded-md text-center">Baca
                                        Selengkapnya</a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <aside class="md:block md:border-l-[2px] border-gray-200 md:pl-6">
                    <h2 class="font-monserrat text-2xl md:text-[32px] text-primary_teks pt-6 md:pt-0"><span
                            class="font-bold text-primary">Persyaratan</span> Terbaru</h2>
                            <?php $__currentLoopData = $latestPersyaratan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persyaratanTerbaru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="flex flex-col py-3 gap-4">
    <div class="flex flex-col gap-2">
<a href="<?php echo e(route('persyaratan.detail', $persyaratanTerbaru->id)); ?>"
    class="font-nunito text-base font-semibold text-primary_teks line-clamp-2"><?php echo e($persyaratanTerbaru->judul); ?></a>
<p class="font-nunito text-sm md:text-base text-secondary_teks "><?php echo e($persyaratanTerbaru->created_at->format('Y-m-d')); ?></p>
<hr class="border-[1.5px] border-gray-200 rounded-full my-3">
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </aside>
            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT LARAVEL\PBL\demo-dukcapil-skh\resources\views/detail-persyaratan.blade.php ENDPATH**/ ?>