<?php $__env->startSection('content'); ?>
    
    <section id="konten-submenu" class="my-10 md:my-20 -z-10">
        <div class="container">
            <div class="flex flex-col md:flex-row justify-between md:gap-6">
                <div class="flex flex-col gap-12">
                    <div class="flex flex-col gap-6 md:gap-12">
                        <h1 class="font-monserrat font-bold text-2xl md:text-[32px] text-primary">
                            <?php echo e($submenu->nama_submenu); ?>

                        </h1>
                        <?php if($kontenSubMenu->isEmpty()): ?>
                            <p class="font-semibold font-monserrat text-xl text-center text-secondary_teks">Detail halalaman
                                ini belum tersedia</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $kontenSubMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($konten->status === 'PUBLISH'): ?>
                                <div class="flex flex-col gap-6 ">
                                    <div class="flex flex-col gap-2">
                                        <?php if($konten->judul !== $submenu->nama_submenu): ?>
                                            <h2 class="font-monserrat font-bold text-2xl md:text-[32px] text-primary_teks ">
                                                <?php echo e($konten->judul); ?>

                                            </h2>
                                        <?php endif; ?>
                                        <p class="font-nunito text-secondary_teks">Dirilis Pada<?php echo e($konten->tanggal); ?></p>
                                    </div>
                                    <div class="flex flex-col gap-4 max-w-screen-lg">
                                        <?php if($konten->gambar): ?>
                                            <img src="<?php echo e($konten->gambar); ?>" alt="<?php echo e($konten->judul); ?>" loading="lazy"
                                                class="rounded-md w-full h-full object-cover object-center">

                                        <?php endif; ?>
                                        <p class="font-nunito text-base text-primary_teks">
                                            <?php echo $konten->deskripsi_konten; ?></p>
                                        <?php if($konten->file): ?>
                                            <a href="<?php echo e(Storage::url($konten->file)); ?>"
                                                class="font-nunito text-base font-semibold text-background_light bg-primary px-3 py-[6px] rounded-md max-w-60">Klik
                                                link file</a>
                                        <?php endif; ?>
                                        <?php if($konten->urls->isEmpty()): ?>

                                        <?php else: ?>
                                        <h3 class="font-monserrat font-bold text-xl text-primary_teks">Link Terkait</h3>
                                            <ul class="list-disc list-inside">
                                                <?php $__currentLoopData = $konten->urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e($url->link_url); ?>" target="_blank"
                                                            class="font-nunito text-base text-primary underline">
                                                            <?php echo e($url->nama_url); ?>

                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                    <p class="text-base text-secondary_teks"></p>
                                    
                                </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="flex flex-col gap-4">
                        <h2 class="font-monserrat text-2xl md:text-[32px] text-primary_teks pt-6 md:pt-0 border-b-2 pb-4">
                            <span class="font-bold text-primary ">Berita</span> Terbaru
                        </h2>
                        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                            <?php $__currentLoopData = $beritaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-col gap-y-3 p-4 border rounded-md">
                                    <img src="<?php echo e(asset('storage/' . $berita->gambar_berita)); ?>"
                                        alt="<?php echo e($berita->judul); ?>"
                                        class="w-full max-h-[450px] object-cover object-center rounded-lg">
                                    <div class="flex gap-1 md:gap-4 items-center justify-between md:justify-start">
                                        <p class="px-2 py-1 bg-primary rounded-sm text-background_light text-xs">Berita</p>
                                        <p class="text-xs text-secondary_teks font-nunito text-end"><?php echo e($berita->waktu); ?>

                                        </p>
                                    </div>
                                    <a href="<?php echo e(route('berita.detail', $berita->id)); ?>"
                                        class="text-base font-bold font-nunito text-primary_teks line-clamp-2"><?php echo e($berita->judul); ?></a>
                                    <p class="text-sm text-secondary_teks line-clamp-2">
                                        <?php echo $berita->deskripsi_berita; ?></p>
                                    <a href="<?php echo e(route('berita.detail', $berita->id)); ?>"
                                        class="mt-2 px-4 py-2 bg-primary text-background_light text-sm rounded-md text-center">Baca
                                        Selengkapnya</a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <aside class="md:block md:border-l-[2px] border-gray-200 md:pl-6">
                    <h2 class="font-monserrat text-2xl md:text-[32px] text-primary_teks pt-6 md:pt-0"><span
                            class="font-bold text-primary ">Persyaratan</span> Terbaru</h2>
                    <div class="flex flex-col py-3 gap-4">
                        <?php $__currentLoopData = $latestPersyaratan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persyaratanTerbaru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="flex flex-col py-3 gap-4">
                            <div class="flex flex-col gap-2">
                        <a href="<?php echo e(route('persyaratan.detail', $persyaratanTerbaru->id)); ?>"
                            class="font-nunito text-base font-semibold text-primary_teks line-clamp-2"><?php echo e($persyaratanTerbaru->judul); ?></a>
                        <p class="font-nunito text-sm md:text-base text-secondary_teks "><?php echo e($persyaratanTerbaru->created_at->format('Y-m-d')); ?></p>
                        <hr class="border-[1.5px] border-gray-200 rounded-full my-3">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </aside>
            </div>
        </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT LARAVEL\PBL\demo-dukcapil-skh\resources\views/konten-submenu.blade.php ENDPATH**/ ?>