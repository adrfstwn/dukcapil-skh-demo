<?php $__env->startSection('content'); ?>
    
    <section id="kontak" class="my-10 md:my-20 ">
        <div class="container">
            <div class=" flex flex-col gap-4 md:gap-6">
                <div class="flex flex-col gap-4">
                    <h2 class="font-monserrat text-2xl md:text-[32px] text-primary font-bold">Temukan Kami</h2>
                    <div class="max-w-screen-xl">
                        <div class="relative" style="padding-top: 56.25%;">
                            <?php $__currentLoopData = $maps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $map): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <iframe
                                src="<?php echo e($map->link_map); ?>"
                                width="800" height="600"
                                style="border:0; position: absolute; top: 0; left: 0; width: 100%; height: 100%;"
                                allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
                                class="w-full h-full rounded-lg md:rounded-2xl">
                            </iframe>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <?php $__currentLoopData = $maps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $map): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-col gap-2 md:gap-3">

                            <h3 class="font-nunito font-bold text-primary_teks text-xl md:text-2xl">Alamat</h3>
                            <p class="font-nunito text-base text-secondary_teks">Alamat : <?php echo e($map->alamat); ?></p>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $jam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex flex-col gap-2 md:gap-3">
                                <h3 class="font-nunito font-bold text-primary_teks text-xl md:text-2xl">Jam Operasional</h3>
                                <ul class="font-nunito text-base text-secondary_teks">
                                    <li>Senin - Kamis (<?php echo e($jam->weekday); ?>)</li>
                                    <li>Jum'at (<?php echo e($jam->jumat); ?>)</li>
                                    <li>Sabtu (<?php echo e($jam->sabtu); ?>)</li>
                                </ul>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex flex-col gap-2 md:gap-3">
                                <h3 class="font-nunito font-bold text-primary_teks text-xl md:text-2xl">Kontak</h3>
                                <ul class="font-nunito text-base text-secondary_teks">
                                    <li>Telp: <?php echo e($kontak->telp); ?> <br>
                                        Fax: <?php echo e($kontak->fax); ?></li>
                                    <li>WA Layanan Pengaduan: <?php echo e($kontak->wa_layan); ?></li>
                                    <li>Email: <?php echo e($kontak->email); ?></li>
                                </ul>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="flex h-80 md:h-64 flex-col md:flex-row gap-12 relative">
                    <div class="bg-gradient-to-r from-primary to-neutral-800 rounded-lg" style="width: 100%; height: 100%;">
                        <img src="<?php echo e(asset('dist/assets/image/Gedung.jpg')); ?>" alt=""
                            class="rounded-lg object-cover opacity-15"
                            style="width: 100%; height: 100%; object-fit: cover;">
                    </div>

                    <div class="absolute p-6 md:p-12 w-full flex flex-col md:flex-row justify-between gap-4 md:gap-10">
                        <div class="flex flex-col">
                            <h4 class="font-monserrat text-base md:text-2xl text-background_light font-bold">Ikuti Kami</h4>
                            <p class="font-monserrat text-sm text-background_light">Temukan kami di media social anda</p>
                        </div>
                        <div class="flex flex-col gap-4 justify-end">
                            <!-- instagram -->
                            <?php $__currentLoopData = $linksos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linksos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-row gap-2 items-center">
                                    <img src="dist/assets/icon/ri_instagram-fill.svg" alt="">
                                    <a href="<?php echo e($linksos->instagram); ?>"
                                        class="font-nunito font-semibold text-background_light"><?php echo e($linksos->nama_instagram); ?></a>
                                </div>
                                <!-- facebook -->
                                <div class="flex flex-row gap-2 items-center">
                                    <img src="dist/assets/icon/facebook-fill.svg" alt="">
                                    <a href="<?php echo e($linksos->facebook); ?>"
                                        class="font-nunito font-semibold text-background_light"><?php echo e($linksos->nama_facebook); ?></a>
                                </div>
                                <!-- twitter -->
                                <div class="flex flex-row gap-2 items-center">
                                    <img src="dist/assets/icon/formkit_twitter.svg" alt="">
                                    <a href="<?php echo e($linksos->x); ?>"
                                        class="font-nunito font-semibold text-background_light"><?php echo e($linksos->nama_x); ?></a>
                                </div>
                                <!-- youtube -->
                                <div class="flex flex-row gap-2 items-center">
                                    <img src="dist/assets/icon/youtube-fill.svg" alt="">
                                    <a href="<?php echo e($linksos->yt); ?>"
                                        class="font-nunito font-semibold text-background_light"><?php echo e($linksos->nama_yt); ?></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT LARAVEL\PBL\demo-dukcapil-skh\resources\views/profil-section/kontak.blade.php ENDPATH**/ ?>